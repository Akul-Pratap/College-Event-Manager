"""
notification_utils.py — Push notifications, email triggers, and WhatsApp link generator
LTSU College Event Management System — Flask API
"""

import json
import os
from datetime import datetime, timezone
from typing import Optional

import requests

# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

FIREBASE_SERVER_KEY = os.getenv("FIREBASE_SERVER_KEY", "")
FIREBASE_FCM_URL = "https://fcm.googleapis.com/fcm/send"

RESEND_API_KEY = os.getenv("RESEND_API_KEY", "")
RESEND_SEND_URL = "https://api.resend.com/emails"
RESEND_FROM_EMAIL = os.getenv("RESEND_FROM_EMAIL", "noreply@ltsuevents.com")
RESEND_FROM_NAME = os.getenv("RESEND_FROM_NAME", "LTSU Events")


# ─────────────────────────────────────────────────────────────────────────────
# Firebase FCM — Push Notifications
# ─────────────────────────────────────────────────────────────────────────────


def send_push_notification(
    fcm_token: str,
    title: str,
    body: str,
    data: Optional[dict] = None,
    image_url: Optional[str] = None,
) -> dict:
    """
    Send a push notification to a single device via Firebase FCM.

    Args:
        fcm_token:  The target device's FCM registration token.
        title:      Notification title.
        body:       Notification body text.
        data:       Optional dict of key-value pairs for the app to handle.
        image_url:  Optional URL for a notification image.

    Returns:
        { "success": bool, "message_id": str, "error": str | None }
    """
    if not FIREBASE_SERVER_KEY:
        return {
            "success": False,
            "message_id": "",
            "error": "FIREBASE_SERVER_KEY is not configured.",
        }

    headers = {
        "Authorization": f"key={FIREBASE_SERVER_KEY}",
        "Content-Type": "application/json",
    }

    notification: dict = {"title": title, "body": body}
    if image_url:
        notification["image"] = image_url

    payload: dict = {
        "to": fcm_token,
        "notification": notification,
        "priority": "high",
    }
    if data:
        payload["data"] = {str(k): str(v) for k, v in data.items()}

    try:
        response = requests.post(
            FIREBASE_FCM_URL,
            headers=headers,
            json=payload,
            timeout=15,
        )
        response.raise_for_status()
        result = response.json()
        success = result.get("success", 0) == 1
        return {
            "success": success,
            "message_id": result.get("results", [{}])[0].get("message_id", ""),
            "error": result.get("results", [{}])[0].get("error")
            if not success
            else None,
        }
    except Exception as exc:
        return {
            "success": False,
            "message_id": "",
            "error": str(exc),
        }


def send_push_to_multiple(
    fcm_tokens: list[str],
    title: str,
    body: str,
    data: Optional[dict] = None,
    image_url: Optional[str] = None,
) -> dict:
    """
    Send a push notification to multiple devices (FCM multicast).

    Args:
        fcm_tokens: List of FCM registration tokens (max 1000 per batch).
        title:      Notification title.
        body:       Notification body text.
        data:       Optional data payload.
        image_url:  Optional notification image URL.

    Returns:
        {
            "success":        bool,
            "success_count":  int,
            "failure_count":  int,
            "results":        list,
            "error":          str | None
        }
    """
    if not fcm_tokens:
        return {
            "success": True,
            "success_count": 0,
            "failure_count": 0,
            "results": [],
            "error": "No tokens provided.",
        }

    if not FIREBASE_SERVER_KEY:
        return {
            "success": False,
            "success_count": 0,
            "failure_count": len(fcm_tokens),
            "results": [],
            "error": "FIREBASE_SERVER_KEY is not configured.",
        }

    # FCM supports max 1000 tokens per multicast call — batch if needed
    batch_size = 1000
    all_results = []
    total_success = 0
    total_failure = 0

    for i in range(0, len(fcm_tokens), batch_size):
        batch = fcm_tokens[i : i + batch_size]

        headers = {
            "Authorization": f"key={FIREBASE_SERVER_KEY}",
            "Content-Type": "application/json",
        }

        notification: dict = {"title": title, "body": body}
        if image_url:
            notification["image"] = image_url

        payload: dict = {
            "registration_ids": batch,
            "notification": notification,
            "priority": "high",
        }
        if data:
            payload["data"] = {str(k): str(v) for k, v in data.items()}

        try:
            response = requests.post(
                FIREBASE_FCM_URL,
                headers=headers,
                json=payload,
                timeout=30,
            )
            response.raise_for_status()
            result = response.json()
            total_success += result.get("success", 0)
            total_failure += result.get("failure", 0)
            all_results.extend(result.get("results", []))
        except Exception as exc:
            total_failure += len(batch)
            all_results.append({"error": str(exc)})

    return {
        "success": total_failure == 0,
        "success_count": total_success,
        "failure_count": total_failure,
        "results": all_results,
        "error": None,
    }


def send_panic_notification(
    fcm_tokens: list[str],
    event_title: str,
    event_id: str,
    message: str = "",
) -> dict:
    """
    Send an emergency panic button notification to all registered attendees.

    Args:
        fcm_tokens:   Tokens of all registered students for the event.
        event_title:  Title of the event.
        event_id:     UUID of the event (passed in data payload).
        message:      Optional custom panic message from the organizer.

    Returns the multicast send result dict.
    """
    title = f"URGENT: {event_title}"
    body = (
        message
        if message
        else (
            f"An urgent update has been issued for {event_title}. "
            "Please check the app immediately."
        )
    )
    data = {
        "event_id": event_id,
        "notification_type": "panic",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    return send_push_to_multiple(fcm_tokens, title, body, data=data)


def send_event_reminder(
    fcm_tokens: list[str],
    event_title: str,
    event_id: str,
    event_date: str,
    venue_name: str,
) -> dict:
    """
    Send a 24-hour event reminder to all registered attendees.
    """
    title = f"Reminder: {event_title} is Tomorrow!"
    body = f"Your event at {venue_name} starts tomorrow ({event_date}). Don't forget to bring your QR code."
    data = {
        "event_id": event_id,
        "notification_type": "reminder",
        "event_date": event_date,
    }
    return send_push_to_multiple(fcm_tokens, title, body, data=data)


def send_approval_notification(
    fcm_token: str,
    event_title: str,
    event_id: str,
    status: str,
    note: str = "",
) -> dict:
    """
    Notify an organizer that their event approval status has changed.

    Args:
        fcm_token:   Organizer's FCM token.
        event_title: Title of the event.
        event_id:    UUID of the event.
        status:      "approved" | "rejected".
        note:        Optional note from the approver.
    """
    if status == "approved":
        title = f"Event Approved: {event_title}"
        body = "Your event has been approved and is now LIVE! Students can register."
    else:
        title = f"Event Rejected: {event_title}"
        body = (
            f"Your event was not approved. Reason: {note}"
            if note
            else ("Your event was not approved. Please review and resubmit.")
        )

    data = {
        "event_id": event_id,
        "notification_type": "approval",
        "status": status,
    }
    return send_push_notification(fcm_token, title, body, data=data)


def send_registration_confirmation(
    fcm_token: str,
    event_title: str,
    event_id: str,
    registration_id: str,
) -> dict:
    """Notify a student that their event registration is confirmed."""
    title = "Registration Confirmed!"
    body = f"You are registered for {event_title}. Your QR ticket is ready in the app."
    data = {
        "event_id": event_id,
        "registration_id": registration_id,
        "notification_type": "registration_confirmed",
    }
    return send_push_notification(fcm_token, title, body, data=data)


def send_waitlist_promoted_notification(
    fcm_token: str,
    event_title: str,
    event_id: str,
) -> dict:
    """Notify a student that they have been promoted off the waitlist."""
    title = "Great news! You're off the waitlist."
    body = f"A spot opened up for {event_title}. Complete your registration now before it expires!"
    data = {
        "event_id": event_id,
        "notification_type": "waitlist_promoted",
    }
    return send_push_notification(fcm_token, title, body, data=data)


def send_duty_leave_update(
    fcm_token: str,
    event_title: str,
    status: str,
    note: str = "",
) -> dict:
    """Notify an organizer/volunteer about their duty leave request status."""
    if status == "approved":
        title = "Duty Leave Approved"
        body = f"Your duty leave request for {event_title} has been approved."
    else:
        title = "Duty Leave Rejected"
        body = f"Your duty leave request for {event_title} was rejected. {note}".strip()
    data = {"notification_type": "duty_leave", "status": status}
    return send_push_notification(fcm_token, title, body, data=data)


# ─────────────────────────────────────────────────────────────────────────────
# Resend — Email Notifications
# ─────────────────────────────────────────────────────────────────────────────


def send_email(
    to_email: str,
    subject: str,
    html_body: str,
    plain_text: Optional[str] = None,
    reply_to: Optional[str] = None,
) -> dict:
    """
    Send a transactional email via the Resend API.

    Args:
        to_email:   Recipient email address.
        subject:    Email subject line.
        html_body:  HTML content of the email.
        plain_text: Optional plain-text fallback.
        reply_to:   Optional reply-to address.

    Returns:
        { "success": bool, "email_id": str, "error": str | None }
    """
    if not RESEND_API_KEY:
        return {
            "success": False,
            "email_id": "",
            "error": "RESEND_API_KEY is not configured.",
        }

    headers = {
        "Authorization": f"Bearer {RESEND_API_KEY}",
        "Content-Type": "application/json",
    }

    payload: dict = {
        "from": f"{RESEND_FROM_NAME} <{RESEND_FROM_EMAIL}>",
        "to": [to_email],
        "subject": subject,
        "html": html_body,
    }

    if plain_text:
        payload["text"] = plain_text
    if reply_to:
        payload["reply_to"] = reply_to

    try:
        response = requests.post(
            RESEND_SEND_URL,
            headers=headers,
            json=payload,
            timeout=15,
        )
        response.raise_for_status()
        result = response.json()
        return {
            "success": True,
            "email_id": result.get("id", ""),
            "error": None,
        }
    except Exception as exc:
        return {
            "success": False,
            "email_id": "",
            "error": str(exc),
        }


def send_registration_email(
    to_email: str,
    student_name: str,
    event_title: str,
    event_date: str,
    venue_name: str,
    registration_id: str,
    qr_base64: Optional[str] = None,
) -> dict:
    """Send a registration confirmation email with QR code to a student."""
    qr_section = ""
    if qr_base64:
        qr_section = f"""
        <div style="text-align:center; margin:24px 0;">
          <p style="font-weight:bold;">Your Entry QR Code</p>
          <img src="{qr_base64}" alt="QR Code" style="width:200px; height:200px;" />
          <p style="font-size:12px; color:#666;">Show this at the event gate.</p>
        </div>
        """

    html = f"""
    <div style="font-family:Arial,sans-serif; max-width:600px; margin:auto; padding:24px;">
      <div style="background:#4F46E5; color:white; padding:20px; border-radius:8px 8px 0 0; text-align:center;">
        <h1 style="margin:0;">LTSU Events</h1>
        <p style="margin:4px 0 0;">Registration Confirmed</p>
      </div>
      <div style="background:#f9fafb; padding:24px; border:1px solid #e5e7eb;">
        <p>Hi <strong>{student_name}</strong>,</p>
        <p>You have successfully registered for:</p>
        <div style="background:white; border:1px solid #e5e7eb; border-radius:8px; padding:16px; margin:16px 0;">
          <h2 style="margin:0 0 8px; color:#4F46E5;">{event_title}</h2>
          <p style="margin:4px 0;">📅 <strong>Date:</strong> {event_date}</p>
          <p style="margin:4px 0;">📍 <strong>Venue:</strong> {venue_name}</p>
          <p style="margin:4px 0;">🎫 <strong>Registration ID:</strong> {registration_id}</p>
        </div>
        {qr_section}
        <p>Please carry a valid college ID card to the event.</p>
        <p style="color:#666; font-size:13px;">This is an automated email from LTSU Events.</p>
      </div>
      <div style="background:#4F46E5; color:white; padding:12px; border-radius:0 0 8px 8px; text-align:center; font-size:12px;">
        Lamrin Tech Skills University — Event Management System
      </div>
    </div>
    """

    subject = f"Registration Confirmed: {event_title}"
    return send_email(to_email, subject, html)


def send_duty_leave_email(
    to_email: str,
    student_name: str,
    event_title: str,
    event_date: str,
    start_time: str,
    end_time: str,
    status: str,
    approved_by_name: str = "",
    note: str = "",
) -> dict:
    """Send a duty leave approval/rejection email."""
    status_color = "#16a34a" if status == "approved" else "#dc2626"
    status_label = "APPROVED" if status == "approved" else "REJECTED"
    note_section = f"<p><strong>Note from approver:</strong> {note}</p>" if note else ""

    html = f"""
    <div style="font-family:Arial,sans-serif; max-width:600px; margin:auto; padding:24px;">
      <div style="background:#4F46E5; color:white; padding:20px; border-radius:8px 8px 0 0; text-align:center;">
        <h1 style="margin:0;">LTSU Events</h1>
        <p style="margin:4px 0 0;">Duty Leave Update</p>
      </div>
      <div style="background:#f9fafb; padding:24px; border:1px solid #e5e7eb;">
        <p>Hi <strong>{student_name}</strong>,</p>
        <p>Your duty leave request has been reviewed:</p>
        <div style="background:white; border:1px solid #e5e7eb; border-radius:8px; padding:16px; margin:16px 0;">
          <p style="margin:4px 0;"><strong>Event:</strong> {event_title}</p>
          <p style="margin:4px 0;"><strong>Date:</strong> {event_date}</p>
          <p style="margin:4px 0;"><strong>Time:</strong> {start_time} – {end_time}</p>
          <p style="margin:4px 0;"><strong>Status:</strong>
            <span style="color:{status_color}; font-weight:bold;">{status_label}</span>
          </p>
          {f'<p style="margin:4px 0;"><strong>Reviewed by:</strong> {approved_by_name}</p>' if approved_by_name else ""}
          {note_section}
        </div>
        <p style="color:#666; font-size:13px;">This is an automated email from LTSU Events.</p>
      </div>
      <div style="background:#4F46E5; color:white; padding:12px; border-radius:0 0 8px 8px; text-align:center; font-size:12px;">
        Lamrin Tech Skills University — Event Management System
      </div>
    </div>
    """

    subject = f"Duty Leave {status_label}: {event_title}"
    return send_email(to_email, subject, html)


def send_payment_status_email(
    to_email: str,
    student_name: str,
    event_title: str,
    amount: float,
    utr: str,
    status: str,
    rejection_reason: str = "",
) -> dict:
    """Send a payment verification result email to a student."""
    status_color = "#16a34a" if status == "approved" else "#dc2626"
    status_label = status.upper()

    html = f"""
    <div style="font-family:Arial,sans-serif; max-width:600px; margin:auto; padding:24px;">
      <div style="background:#4F46E5; color:white; padding:20px; border-radius:8px 8px 0 0; text-align:center;">
        <h1 style="margin:0;">LTSU Events</h1>
        <p style="margin:4px 0 0;">Payment Update</p>
      </div>
      <div style="background:#f9fafb; padding:24px; border:1px solid #e5e7eb;">
        <p>Hi <strong>{student_name}</strong>,</p>
        <div style="background:white; border:1px solid #e5e7eb; border-radius:8px; padding:16px; margin:16px 0;">
          <p style="margin:4px 0;"><strong>Event:</strong> {event_title}</p>
          <p style="margin:4px 0;"><strong>Amount:</strong> Rs. {amount:.2f}</p>
          <p style="margin:4px 0;"><strong>UTR:</strong> {utr}</p>
          <p style="margin:4px 0;"><strong>Status:</strong>
            <span style="color:{status_color}; font-weight:bold;">{status_label}</span>
          </p>
          {f'<p style="margin:4px 0; color:#dc2626;"><strong>Reason:</strong> {rejection_reason}</p>' if rejection_reason else ""}
        </div>
        <p style="color:#666; font-size:13px;">This is an automated email from LTSU Events.</p>
      </div>
    </div>
    """

    subject = f"Payment {status_label}: {event_title}"
    return send_email(to_email, subject, html)


# ─────────────────────────────────────────────────────────────────────────────
# WhatsApp Link Generator
# ─────────────────────────────────────────────────────────────────────────────


def generate_whatsapp_link(
    message: str,
    phone_number: Optional[str] = None,
) -> str:
    """
    Generate a WhatsApp share link for an event message.

    Args:
        message:      The text message to pre-fill in WhatsApp.
        phone_number: Optional E.164 phone number (e.g. "919876543210").
                      If provided, opens a direct chat. Otherwise, opens share.

    Returns:
        A WhatsApp URL string.
    """
    import urllib.parse

    encoded_message = urllib.parse.quote(message, safe="")

    if phone_number:
        # Remove any non-digit characters
        clean_number = "".join(filter(str.isdigit, phone_number))
        return f"https://wa.me/{clean_number}?text={encoded_message}"
    else:
        return f"https://wa.me/?text={encoded_message}"


def generate_event_whatsapp_message(event: dict, registration_link: str) -> str:
    """
    Generate a formatted WhatsApp message for an event announcement.

    Args:
        event:              Event dict (title, date, venue, fee, description).
        registration_link:  Full URL to the event registration page.

    Returns:
        A ready-to-send WhatsApp message string.
    """
    title = event.get("title", "Event")
    date = event.get("date", "TBD")
    venue = (event.get("venues") or {}).get("name", event.get("venue_name", "TBD"))
    fee = float(event.get("fee", 0))
    fee_text = f"Rs. {fee:.0f}" if fee > 0 else "Free Entry"
    description = event.get("description", "")
    club_name = (event.get("clubs") or {}).get("name", "")

    message_lines = [
        f"🎉 *{title}*",
        "",
        f"📅 Date: {date}",
        f"📍 Venue: {venue}",
        f"💰 Fee: {fee_text}",
    ]

    if club_name:
        message_lines.append(f"🏫 Organized by: {club_name}")

    if description:
        message_lines.extend(["", description[:200]])

    message_lines.extend(
        [
            "",
            "🔗 Register now:",
            registration_link,
            "",
            "⚡ Limited seats — register early!",
            "",
            "_LTSU Events — Lamrin Tech Skills University_",
        ]
    )

    return "\n".join(message_lines)


def generate_whatsapp_share_link(event: dict, registration_link: str) -> str:
    """
    Convenience function: build the WhatsApp share URL for an event.
    """
    message = generate_event_whatsapp_message(event, registration_link)
    return generate_whatsapp_link(message)


# ─────────────────────────────────────────────────────────────────────────────
# Notification Audit — log to Supabase
# ─────────────────────────────────────────────────────────────────────────────


def log_notification_sent(
    user_id: str,
    notification_type: str,
    message: str,
    event_id: Optional[str] = None,
) -> None:
    """
    Create an in-app notification record in the notifications table
    and a corresponding email_logs entry if applicable.

    Non-critical — failures are silently caught.
    """
    try:
        from models import create_notification

        create_notification(
            {
                "user_id": user_id,
                "type": notification_type,
                "message": message,
                "is_read": False,
            }
        )
    except Exception:
        pass

    if event_id:
        try:
            from models import log_email

            log_email(
                {
                    "user_id": user_id,
                    "event_id": event_id,
                    "trigger_type": notification_type,
                    "sent_at": datetime.now(timezone.utc).isoformat(),
                    "status": "sent",
                }
            )
        except Exception:
            pass
