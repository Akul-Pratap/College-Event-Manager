import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/auth_service.dart';

class OrganizerDashboard extends StatelessWidget {
  const OrganizerDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Organizer Panel'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              final auth = context.read<AuthService>();
              await auth.logout();
              if (context.mounted) {
                Navigator.of(context).pushReplacementNamed('/login');
              }
            },
          ),
        ],
      ),
      body: GridView.count(
        crossAxisCount: 2,
        padding: const EdgeInsets.all(16),
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        children: [
          _buildDashboardCard(
              context, Icons.add_circle_outline, 'Create Event', Colors.blue),
          _buildDashboardCard(
              context, Icons.people_outline, 'Manage Attendees', Colors.orange),
          _buildDashboardCard(
              context, Icons.qr_code_scanner, 'Check-in Desk', Colors.green),
          _buildDashboardCard(context, Icons.warning_amber_rounded,
              'Emergency Alert', Colors.red),
          _buildDashboardCard(
              context, Icons.chat_bubble_outline, 'Broadcast', Colors.purple),
          _buildDashboardCard(
              context, Icons.monetization_on_outlined, 'Finance', Colors.teal),
        ],
      ),
    );
  }

  Widget _buildDashboardCard(
      BuildContext context, IconData icon, String title, Color color) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        onTap: () {},
        borderRadius: BorderRadius.circular(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
                radius: 30,
                backgroundColor: color.withValues(alpha: 0.1),
                child: Icon(icon, size: 30, color: color)),
            const SizedBox(height: 12),
            Text(title,
                style: const TextStyle(fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
