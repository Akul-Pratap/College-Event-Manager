import os
from supabase import create_client

url = "https://twuusmqrcwlrtxjskcge.supabase.co"
key = "sb_publishable_rB9D-ndyN_tL3R1mIkFcyw_uXEZxRG-" 
supa = create_client(url, key)

# Let's test connection by fetching departments
try:
    response = supa.table("departments").select("*").execute()
    print("Departments exist:", response.data)
except Exception as e:
    print("Database error:", e)
