"use server";

import { auth, clerkClient } from "@clerk/nextjs/server";

export async function completeOnboarding(department: string, role: string) {
  const { userId } = await auth();
  if (!userId) return { success: false, error: "Not authorized" };
  
  try {
    const client = await clerkClient();
    await client.users.updateUserMetadata(userId, {
      publicMetadata: {
        department,
        role
      }
    });
    return { success: true };
  } catch (error) {
    console.error("Error updating user metadata", error);
    return { success: false, error: "Failed to update profile." };
  }
}
