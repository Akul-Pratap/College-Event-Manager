"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@clerk/nextjs";
import { motion } from "framer-motion";
import {
  CheckCircle, XCircle, Clock, MessageSquare, Loader2, AlertTriangle,
} from "lucide-react";
import Link from "next/link";
import { useParams } from "next/navigation";

interface ApprovalRequest {
  id: string;
  stage: 1 | 2;
  approver_role: "faculty_coordinator" | "hod";
  status: "pending" | "approved" | "rejected";
  note: string | null;
  requested_at: string;
  events?: {
    id: string;
    title: string;
    date: string;
    clubs?: { name: string };
    creators?: { name: string };
  };
}

export default function HODApprovalsPage() {
  const { getToken } = useAuth();
  const params = useParams();
  const dept = params?.dept as string;

  const [approvals, setApprovals] = useState<ApprovalRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<string | null>(null);
  const [noteInputs, setNoteInputs] = useState<Record<string, string>>({});
  const [filter, setFilter] = useState<"pending" | "approved" | "rejected" | "all">("pending");
  const [error, setError] = useState<string | null>(null);

  const flaskUrl = process.env.NEXT_PUBLIC_FLASK_API_URL ?? "http://localhost:5000";

  useEffect(() => {
    async function load() {
      try {
        const token = await getToken();
        const res = await fetch(`${flaskUrl}/api/approvals/hod`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();
        setApprovals(data.approvals ?? []);
      } catch (err) {
        setError("Could not load approvals.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [flaskUrl, getToken]);

  async function decide(approvalId: string, status: "approved" | "rejected") {
    setUpdating(approvalId);
    setError(null);
    try {
      const token = await getToken();
      const res = await fetch(`${flaskUrl}/api/approvals/${approvalId}/decide`, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ status, note: noteInputs[approvalId] ?? "" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed to update");
      setApprovals((prev) => prev.map((a) => a.id === approvalId ? { ...a, status, note: noteInputs[approvalId] } : a));
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUpdating(null);
    }
  }

  const filtered = approvals.filter((a) => filter === "all" || a.status === filter);
  const pendingCount = approvals.filter((a) => a.status === "pending").length;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 h-16 flex items-center gap-4">
          <Link href={`/dashboard/${dept}/hod`} className="text-sm text-muted-foreground hover:text-foreground transition">← Back</Link>
          <span className="font-bold text-foreground">Event Approvals</span>
          {pendingCount > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-primary text-primary-foreground text-xs font-bold">{pendingCount}</span>
          )}
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
        {/* Progress bar */}
        {approvals.length > 0 && (
          <div className="rounded-2xl border border-border bg-card p-4 mb-6 grid grid-cols-3 gap-3 text-center">
            {[
              { label: "Pending", value: approvals.filter(a => a.status === "pending").length, color: "text-amber-600" },
              { label: "Approved", value: approvals.filter(a => a.status === "approved").length, color: "text-green-600" },
              { label: "Rejected", value: approvals.filter(a => a.status === "rejected").length, color: "text-destructive" },
            ].map(({ label, value, color }) => (
              <div key={label}>
                <div className={`text-2xl font-bold ${color}`}>{value}</div>
                <div className="text-xs text-muted-foreground">{label}</div>
              </div>
            ))}
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-1 border-b border-border mb-6">
          {(["pending", "approved", "rejected", "all"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 -mb-px capitalize transition-colors ${
                filter === tab ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {error && <div className="rounded-xl border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive mb-4">{error}</div>}

        {loading ? (
          <div className="flex justify-center py-16"><Loader2 className="w-7 h-7 animate-spin text-muted-foreground" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16">
            <CheckCircle className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-40" />
            <p className="text-lg font-medium text-muted-foreground">No {filter} approvals</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filtered.map((req, i) => (
              <motion.div
                key={req.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="rounded-2xl border border-border bg-card p-5 space-y-4"
              >
                {/* Header */}
                <div className="flex items-start gap-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    req.status === "approved" ? "bg-green-500/10"
                      : req.status === "rejected" ? "bg-destructive/10"
                      : "bg-amber-500/10"
                  }`}>
                    {req.status === "approved" ? <CheckCircle className="w-5 h-5 text-green-500" />
                      : req.status === "rejected" ? <XCircle className="w-5 h-5 text-destructive" />
                      : <Clock className="w-5 h-5 text-amber-500" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-bold text-foreground">{req.events?.title ?? "Event"}</p>
                      <span className="px-2 py-0.5 rounded-full text-xs bg-primary/10 text-primary">Stage {req.stage}/2</span>
                    </div>
                    {req.events?.clubs?.name && (
                      <p className="text-xs text-muted-foreground mt-0.5">Organised by {req.events.clubs.name}</p>
                    )}
                    <p className="text-xs text-muted-foreground">
                      Requested {new Date(req.requested_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                      {req.events?.date && ` · Event: ${new Date(req.events.date).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}`}
                    </p>
                  </div>
                  {req.note && (
                    <div className="flex items-start gap-1 text-xs text-muted-foreground max-w-[160px]">
                      <MessageSquare className="w-3 h-3 mt-0.5 shrink-0" />
                      <span className="line-clamp-2">{req.note}</span>
                    </div>
                  )}
                </div>

                {/* Actions — only for pending */}
                {req.status === "pending" && (
                  <div className="space-y-3">
                    <textarea
                      value={noteInputs[req.id] ?? ""}
                      onChange={(e) => setNoteInputs((prev) => ({ ...prev, [req.id]: e.target.value }))}
                      placeholder="Add a decision note (optional)…"
                      rows={2}
                      className="w-full px-3 py-2 rounded-xl border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                    />
                    <div className="flex gap-3">
                      <button
                        onClick={() => decide(req.id, "approved")}
                        disabled={updating === req.id}
                        className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-green-500/10 text-green-600 border border-green-500/30 text-sm font-semibold hover:bg-green-500/20 transition disabled:opacity-50"
                      >
                        {updating === req.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                        Approve
                      </button>
                      <button
                        onClick={() => decide(req.id, "rejected")}
                        disabled={updating === req.id}
                        className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-destructive/10 text-destructive border border-destructive/30 text-sm font-semibold hover:bg-destructive/20 transition disabled:opacity-50"
                      >
                        <XCircle className="w-4 h-4" />
                        Reject
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
